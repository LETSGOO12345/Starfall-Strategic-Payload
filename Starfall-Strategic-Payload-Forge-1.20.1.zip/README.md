# Starfall: Strategic Payload (Minecraft Forge 1.20.1)

A cinematic fictional nuclear strike mod for Forge 1.20.1 / Forge 47.x / Java 17.

## Included
- Targeting remote item with a 3D model in inventory and hand.
- Right-click targeting: aims at a block up to 128 blocks away; if no block is hit, targets a point 40 blocks ahead.
- A visible 3D warhead entity drops from high altitude at the target.
- Missile trail, smoke, sparks, fire and a large impact particle burst.
- Impact-frame flash, letterbox and camera shake.
- Toggleable cinematic overlay with the **K** key.
- Layered warning, launch, bass impact and roar cues using Minecraft sound events.
- Large in-game explosion (24-block power). Back up worlds before testing.

## Build on GitHub from Android
1. Upload the CONTENTS of this project ZIP to a GitHub repository (keep paths intact).
2. The included `.github/workflows/build.yml` automatically builds on push.
3. Open Actions -> latest successful run -> Artifacts -> `Starfall-Overhaul-JAR`.
4. Download the artifact ZIP and extract the `.jar` inside.

No Gradle wrapper is required for GitHub Actions; the workflow installs Gradle 8.8.

## Install
- Minecraft Java 1.20.1
- Forge 1.20.1, Forge 47.x
- Java 17
- Put `starfall-overhaul-2.0.0.jar` in the selected instance's `mods` folder.

## Use
- Enter Creative Mode and find **Starfall Targeting Remote** in the Starfall Arsenal tab.
- Aim at a block / location and right-click to launch.
- Press **K** to toggle the cinematic overlay/camera treatment on or off.
- The strike is destructive; test in a disposable world.

## Scope / limitations
This is a substantial playable mod foundation, not a cinematic film renderer. The cutscene is a client-side camera shake, impact-frame flash and letterbox treatment; it does not take control away from the player or move the camera to a scripted third-person shot. Sound cues use Minecraft's built-in sound library. Custom animated audio, post-processing shaders, multiplayer spectator camera choreography, radiation gameplay, and bespoke Blockbench animation assets would be separate expansion work.
