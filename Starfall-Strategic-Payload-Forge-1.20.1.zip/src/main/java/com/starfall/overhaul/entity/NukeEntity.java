package com.starfall.overhaul.entity;

import com.starfall.overhaul.network.ModNetwork;
import com.starfall.overhaul.network.NukeImpactPacket;
import com.starfall.overhaul.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class NukeEntity extends Entity {
    private static final EntityDataAccessor<Float> TARGET_Y = SynchedEntityData.defineId(NukeEntity.class, EntityDataSerializers.FLOAT);
    private int age;

    public NukeEntity(EntityType<? extends NukeEntity> type, Level level) { super(type, level); }
    @Override protected void defineSynchedData() { this.entityData.define(TARGET_Y, 64.0F); }
    public void setTargetY(double y) { this.entityData.set(TARGET_Y, (float)y); }
    public float getTargetY() { return this.entityData.get(TARGET_Y); }

    @Override public void tick() {
        super.tick();
        age++;
        if (level().isClientSide) {
            if (age % 2 == 0) {
                level().addParticle(net.minecraft.core.particles.ParticleTypes.FLAME, getX(), getY() + 0.3, getZ(), 0, -0.04, 0);
                level().addParticle(net.minecraft.core.particles.ParticleTypes.SMOKE, getX(), getY() - 0.7, getZ(), 0, -0.12, 0);
                if (age % 5 == 0) level().addParticle(net.minecraft.core.particles.ParticleTypes.END_ROD, getX(), getY() + 1.2, getZ(), 0, -0.3, 0);
            }
        } else {
            double speed = Math.min(2.6D, 0.85D + age * 0.025D);
            setDeltaMovement(0.0D, -speed, 0.0D);
            move(net.minecraft.world.entity.MoverType.SELF, getDeltaMovement());
            if (getY() <= getTargetY() || age > 260) impact();
        }
    }

    private void impact() {
        if (!(level() instanceof ServerLevel server)) { discard(); return; }
        double x = getX(), y = getTargetY(), z = getZ();
        NukeEffects.detonate(server, x, y, z);
        server.playSound(null, BlockPos.containing(x, y, z), ModSounds.IMPACT_BASS.get(), SoundSource.BLOCKS, 8.0F, 0.55F);
        server.playSound(null, BlockPos.containing(x, y, z), ModSounds.IMPACT_ROAR.get(), SoundSource.BLOCKS, 7.0F, 0.8F);
        ModNetwork.sendImpact(server, x, y, z);
        discard();
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("TargetY")) setTargetY(tag.getFloat("TargetY"));
        age = tag.getInt("Age");
    }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("TargetY", getTargetY());
        tag.putInt("Age", age);
    }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
}
