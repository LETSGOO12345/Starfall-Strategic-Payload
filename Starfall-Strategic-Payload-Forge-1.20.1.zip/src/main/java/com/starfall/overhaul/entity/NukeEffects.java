package com.starfall.overhaul.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

public class NukeEffects {
    private NukeEffects() {}
    public static void detonate(ServerLevel level, double x, double y, double z) {
        // A multi-layered visual burst: flash, hot core, outward debris, then tall smoke column.
        level.sendParticles(ParticleTypes.FLASH, x, y + 1, z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1, z, 2, 0.2, 0.2, 0.2, 0);
        level.sendParticles(ParticleTypes.EXPLOSION, x, y + 1, z, 180, 8, 3, 8, 0.25);
        level.sendParticles(ParticleTypes.FLAME, x, y + 1, z, 360, 9, 3, 9, 0.24);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y + 1, z, 110, 6, 3, 6, 0.12);
        level.sendParticles(ParticleTypes.LAVA, x, y + 1, z, 85, 7, 4, 7, 0.18);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y + 3, z, 420, 5, 3, 5, 0.22);
        level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, x, y + 7, z, 220, 3, 4, 3, 0.11);
        level.sendParticles(ParticleTypes.CLOUD, x, y + 1, z, 170, 11, 1.2, 11, 0.2);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 2, z, 130, 8, 5, 8, 0.25);
        // Powerful fictional in-game blast. Keep a backup of worlds before testing.
        level.explode(null, x, y, z, 24.0F, true, Level.ExplosionInteraction.TNT);
    }
}
