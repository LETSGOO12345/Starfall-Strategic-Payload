package com.starfall.overhaul.network;

import com.starfall.overhaul.StarfallMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(StarfallMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;
    public static void register() {
        CHANNEL.messageBuilder(NukeImpactPacket.class, id++, net.minecraftforge.network.NetworkDirection.PLAY_TO_CLIENT)
                .encoder(NukeImpactPacket::encode).decoder(NukeImpactPacket::decode)
                .consumerMainThread(NukeImpactPacket::handle).add();
    }
    public static void sendImpact(ServerLevel level, double x, double y, double z) {
        CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, 160, level.dimension())), new NukeImpactPacket(x, y, z));
    }
}
