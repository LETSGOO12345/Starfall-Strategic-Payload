package com.starfall.overhaul.network;

import com.starfall.overhaul.client.CinematicController;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class NukeImpactPacket {
    private final double x, y, z;
    public NukeImpactPacket(double x, double y, double z) { this.x=x; this.y=y; this.z=z; }
    public static void encode(NukeImpactPacket msg, FriendlyByteBuf buf) { buf.writeDouble(msg.x); buf.writeDouble(msg.y); buf.writeDouble(msg.z); }
    public static NukeImpactPacket decode(FriendlyByteBuf buf) { return new NukeImpactPacket(buf.readDouble(), buf.readDouble(), buf.readDouble()); }
    public static void handle(NukeImpactPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> CinematicController.trigger(msg.x, msg.y, msg.z)));
        ctx.get().setPacketHandled(true);
    }
}
