package com.starfall.overhaul.registry;

import com.starfall.overhaul.StarfallMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    private static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StarfallMod.MODID);
    public static final RegistryObject<SoundEvent> LAUNCH_WARNING = register("launch_warning");
    public static final RegistryObject<SoundEvent> PAYLOAD_DROP = register("payload_drop");
    public static final RegistryObject<SoundEvent> IMPACT_BASS = register("impact_bass");
    public static final RegistryObject<SoundEvent> IMPACT_ROAR = register("impact_roar");
    private static RegistryObject<SoundEvent> register(String name) {
        ResourceLocation id = new ResourceLocation(StarfallMod.MODID, name);
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
    public static void register(IEventBus bus) { SOUNDS.register(bus); }
}
