package com.starfall.overhaul.registry;

import com.starfall.overhaul.StarfallMod;
import com.starfall.overhaul.entity.NukeEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    private static final DeferredRegister<EntityType<?>> TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StarfallMod.MODID);
    public static final RegistryObject<EntityType<NukeEntity>> NUKE = TYPES.register("nuke",
            () -> EntityType.Builder.<NukeEntity>of(NukeEntity::new, MobCategory.MISC)
                    .sized(0.9F, 2.6F).clientTrackingRange(128).updateInterval(1).fireImmune().build("nuke"));
    public static void register(IEventBus bus) { TYPES.register(bus); }
}
