package com.starfall.overhaul.item;

import com.starfall.overhaul.entity.NukeEntity;
import com.starfall.overhaul.registry.ModEntities;
import com.starfall.overhaul.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class NuclearRemoteItem extends Item {
    public NuclearRemoteItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(level instanceof ServerLevel server)) return InteractionResultHolder.fail(stack);

        HitResult hit = player.pick(128.0D, 0.0F, false);
        Vec3 target;
        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hit;
            BlockPos p = blockHit.getBlockPos().relative(blockHit.getDirection());
            target = new Vec3(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
        } else {
            target = player.getEyePosition().add(player.getLookAngle().scale(40.0D));
        }

        NukeEntity nuke = ModEntities.NUKE.get().create(server);
        if (nuke == null) return InteractionResultHolder.fail(stack);
        nuke.setTargetY(target.y);
        nuke.setPos(target.x, target.y + 62.0D, target.z);
        nuke.setDeltaMovement(0.0D, -0.85D, 0.0D);
        server.addFreshEntity(nuke);
        server.playSound(null, BlockPos.containing(target), ModSounds.LAUNCH_WARNING.get(), SoundSource.PLAYERS, 4.0F, 0.7F);
        server.playSound(null, BlockPos.containing(target), ModSounds.PAYLOAD_DROP.get(), SoundSource.PLAYERS, 2.5F, 0.8F);
        player.getCooldowns().addCooldown(this, 160);
        player.displayClientMessage(Component.literal("TARGET LOCKED — PAYLOAD INBOUND").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
