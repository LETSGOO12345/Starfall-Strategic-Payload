package com.starfall.overhaul;

import com.starfall.overhaul.registry.ModEntities;
import com.starfall.overhaul.registry.ModItems;
import com.starfall.overhaul.registry.ModSounds;
import com.starfall.overhaul.network.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(StarfallMod.MODID)
public class StarfallMod {
    public static final String MODID = "starfall";
    public StarfallMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(bus);
        ModEntities.register(bus);
        ModSounds.register(bus);
        ModNetwork.register();
    }
}
