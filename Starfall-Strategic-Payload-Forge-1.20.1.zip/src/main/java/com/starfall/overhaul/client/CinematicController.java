package com.starfall.overhaul.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "starfall", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class CinematicController {
    private static int ticks = 0;
    private static boolean active = false;
    private static boolean cinematicEnabled = true;
    private static double impactX, impactY, impactZ;
    public static void trigger(double x, double y, double z) {
        impactX=x; impactY=y; impactZ=z;
        if (cinematicEnabled) { active = true; ticks = 0; }
    }
    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (StarfallKeybinds.TOGGLE.consumeClick()) {
            cinematicEnabled = !cinematicEnabled;
            if (mc.player != null) mc.player.displayClientMessage(Component.literal("Nuke cinematic: " + (cinematicEnabled ? "ON" : "OFF")), true);
            if (!cinematicEnabled) active = false;
        }
        if (active) {
            ticks++;
            if (ticks > 150) active = false;
        }
    }
    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles event) {
        if (!active || ticks > 95) return;
        float strength = ticks < 25 ? 1.0F : Math.max(0.0F, 1.0F - (ticks - 25) / 70.0F);
        float shake = (float)Math.sin(ticks * 2.7) * 2.8F * strength;
        event.setYaw(event.getYaw() + shake);
        event.setPitch(event.getPitch() + shake * 0.7F);
        event.setRoll(event.getRoll() + shake * 0.25F);
    }
    @SubscribeEvent
    public static void overlay(RenderGuiOverlayEvent.Post event) {
        if (!active) return;
        int w = event.getWindow().getGuiScaledWidth(), h = event.getWindow().getGuiScaledHeight();
        var g = event.getGuiGraphics();
        if (ticks < 7 || (ticks >= 10 && ticks < 13)) {
            int alpha = ticks < 7 ? Math.max(0, 255 - ticks * 30) : 150;
            g.fill(0, 0, w, h, (alpha << 24) | 0xFFF0C9);
        }
        if (ticks > 4 && ticks < 110) {
            int bar = Math.max(3, h / 12);
            g.fill(0, 0, w, bar, 0xFF050609);
            g.fill(0, h - bar, w, h, 0xFF050609);
        }
        if (ticks > 14 && ticks < 90) {
            String title = ticks < 42 ? "STARFALL IMPACT" : "SIGNAL LOST";
            g.drawCenteredString(Minecraft.getInstance().font, title, w / 2, h / 2 + h / 4, 0xFFFFD27A);
        }
    }
}
