package com.starfall.overhaul.client;

import com.starfall.overhaul.StarfallMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = StarfallMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class StarfallKeybinds {
    public static final KeyMapping TOGGLE = new KeyMapping("key.starfall.toggle_cinematic", GLFW.GLFW_KEY_K, "key.categories.starfall");
    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) { event.register(TOGGLE); }
}
