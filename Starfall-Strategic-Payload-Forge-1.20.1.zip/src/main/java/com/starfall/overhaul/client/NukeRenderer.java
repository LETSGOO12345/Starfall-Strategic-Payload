package com.starfall.overhaul.client;

import com.starfall.overhaul.entity.NukeEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class NukeRenderer extends EntityRenderer<NukeEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("starfall", "textures/entity/nuke.png");
    private final NukeModel model;
    public NukeRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new NukeModel(context.bakeLayer(NukeModel.LAYER));
        this.shadowRadius = 0.8F;
    }
    @Override public void render(NukeEntity entity, float yaw, float partialTicks, PoseStack pose, MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.scale(0.8F, 0.8F, 0.8F);
        pose.mulPose(com.mojang.math.Axis.XP.rotationDegrees(180F));
        model.setupAnim(entity, 0, 0, entity.tickCount + partialTicks, 0, 0);
        model.renderToBuffer(pose, buffer.getBuffer(net.minecraft.client.renderer.RenderType.entityCutoutNoCull(TEXTURE)), light, OverlayTexture.NO_OVERLAY, 1,1,1,1);
        pose.popPose();
        super.render(entity, yaw, partialTicks, pose, buffer, light);
    }
    @Override public ResourceLocation getTextureLocation(NukeEntity entity) { return TEXTURE; }
}
