package com.starfall.overhaul.client;

import com.starfall.overhaul.entity.NukeEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

public class NukeModel extends EntityModel<NukeEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation("starfall", "nuke"), "main");
    private final ModelPart root;
    public NukeModel(ModelPart root) { this.root = root; }
    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("warhead", CubeListBuilder.create().texOffs(0,0).addBox(-3F,-10F,-3F,6F,15F,6F), PartPose.ZERO);
        root.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(24,0).addBox(-2F,-14F,-2F,4F,5F,4F), PartPose.ZERO);
        root.addOrReplaceChild("fin_a", CubeListBuilder.create().texOffs(0,24).addBox(-5F,2F,-1F,3F,5F,2F), PartPose.ZERO);
        root.addOrReplaceChild("fin_b", CubeListBuilder.create().texOffs(0,24).addBox(2F,2F,-1F,3F,5F,2F), PartPose.ZERO);
        root.addOrReplaceChild("fin_c", CubeListBuilder.create().texOffs(0,24).addBox(-1F,2F,-5F,2F,5F,3F), PartPose.ZERO);
        root.addOrReplaceChild("fin_d", CubeListBuilder.create().texOffs(0,24).addBox(-1F,2F,2F,2F,5F,3F), PartPose.ZERO);
        root.addOrReplaceChild("band", CubeListBuilder.create().texOffs(24,16).addBox(-3.2F,-2F,-3.2F,6.4F,2F,6.4F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }
    @Override public void setupAnim(NukeEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        root.yRot = ageInTicks * 0.04F;
    }
    @Override public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack pose, com.mojang.blaze3d.vertex.VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
